﻿namespace Aircompany.Models
{
    public enum MilitaryAirplaneType
    {
        Fighter,
        Bomber,
        Transport
    }
}
